class EngineeringState:
    def __init__(self):
        self.task = None
        self.stage = "init"
        self.constraints = {}
        self.memory = []
        self.computed = {}

    def update(self, key, value):
        setattr(self, key, value)

    def to_dict(self):
        return {
            "task": self.task,
            "stage": self.stage,
            "constraints": self.constraints,
            "computed": self.computed
        }
