from agent.state import EngineeringState
from rag.parser import parse_text
from tools.rf_tools import calc_gain

class EngineerAgent:
    def __init__(self):
        self.state = EngineeringState()

    def run(self, query: str):

        if "LNA" in query or "设计" in query:
            self.state.task = "RF_LNA"

        if "增益" in query:
            gain = calc_gain(10, 2)
            self.state.computed["gain"] = gain
            return f"计算得到增益: {gain} dB"

        if "datasheet" in query:
            data = parse_text(query)
            self.state.constraints.update(data)
            return f"已解析文档: {data}"

        return f"当前任务: {self.state.task}, stage: {self.state.stage}"
