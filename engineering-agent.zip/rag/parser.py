def parse_text(text: str):
    return {
        "freq": "2.4GHz",
        "gain": "18dB",
        "noise_figure": "0.8dB"
    }
