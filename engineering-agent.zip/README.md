# Engineering Agent Demo

## Run
pip install -r requirements.txt
uvicorn app:app --reload

## API
POST /chat?query=xxx
