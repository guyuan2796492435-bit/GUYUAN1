def calc_gain(gm, rl):
    return 10 * (gm / rl)
