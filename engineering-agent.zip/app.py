from fastapi import FastAPI
from agent.engineer_agent import EngineerAgent

app = FastAPI()
agent = EngineerAgent()

@app.post('/chat')
def chat(query: str):
    result = agent.run(query)
    return {'response': result}
